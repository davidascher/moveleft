A Pen created at CodePen.io. You can find this one at http://codepen.io/davidascher/pen/LRkrEp.

 Testing out steps timing function as opposed to normal easing