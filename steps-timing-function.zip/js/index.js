var Thing = function() {
  this.message = 'Controls';
  this.period = 60;
  this.mode = 'single';
  this.backAndForth = false;
  this.direction = 'left';
  this.explode = function() {
  };  
}



var controls = new Thing();
var JSON = {
  "preset": "Left Right 60",
  "mode": "single",
  "remembered": {
    "Default": {
      "0": {}
    },
    "Left": {
      "0": {
        "direction": "left",
        "period": 60
      }
    },
    "Right": {
      "0": {
        "direction": "right",
        "period": 60
      }
    },
    "Left Right 60": {
      "0": {
        "direction": "leftright",
        "period": 60
      }
    }
  },
  "closed": false,
  "folders": {}
}

function play () {
  $("#go").text("Pause")
  $(".box").css({'animation-play-state': 'running'});  
}
function pause () {
  $("#go").text("Play")
  $(".box").css({'animation-play-state': 'paused'});  
}
var playing = true;
function playpause() {
  console.log("in playpause");
  playing = ! playing;
  if (playing) {
    pause();
  } else {
    play();
  }
}
var gui = new dat.GUI({load: JSON});
var dir = gui.add(controls, 'direction', [ 'left', 'right', 'leftright' ] );
var mode = gui.add(controls, 'mode', [ 'single', 'loop' ] );

$("#go").text("Restart")
$('#go').on('click.reset', function( ) { reset()  });
$('#go').off('click.playpause');


mode.onChange(function(value) {
  let iterCount = '1'
  if (value === "single") {
    iterCount = '1' 
    $("#go").text("Restart")
    $('#go').on('click.reset', function( ) { reset()  });
    $('#go').off('click.playpause');
  } else {
    iterCount = 'infinite';
    pause();
    $('#go').off('click.reset');
    $('#go').on('click.playpause', function( ) { playpause()  });
  }
  console.log("iterCount", iterCount)
  $(".box").css({'animation-iteration-count': iterCount});
  reset()
})

reset = function () {
  console.log("in reset");
  var elm = document.getElementById('dot')
var newone = elm.cloneNode(true);
elm.parentNode.replaceChild(newone, elm);
}
dir.onFinishChange(function(value) {
  console.log('direction', value)
  $(".box").css({'animation-name': value})
  reset()
  
})

var controller = gui.add(controls, 'period', 1, 120);

controller.onChange(function(value) {
  value = String(Math.round(value))
  $(".box").css({'animation-duration':  value+'s'});
  reset()

  // console.log(value)
  // Fires on every change, drag, keypress, etc.
});
gui.remember(controls);